﻿Imports KendyAlfaro
Public Class LogicaPersona
    Private lista As New List(Of Persona)

    Function agregar(p As Persona) As String
        Dim msg As String = "NO Se agrego la persona con cedula" & p.ced & " al sistema"
        Try
            If validar(p.ced) Then
                lista.Add(p)
                msg = "Se agrego la persona " & p.nom & " al sistema"
            End If

            Return msg '"Se agrego la persona " & p.Nombre & " al sistema"
        Catch ex As Exception
            Return msg
        End Try
    End Function

    Private Function validar(ced As Long) As Boolean
        For i = 0 To total() - 1
            If (ced = persona(i).ced) Then
                Return False
            End If
        Next
        Return True
    End Function

    Function buscar(c As Long) As Persona
        Try
            For Each obj As Object In lista
                If CType(obj, Persona).ced = c Then
                    Return CType(obj, Persona)
                End If
            Next
            Return Nothing
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Function buscarPosicion(ced As Long) As Integer
        Dim i As Integer = -1
        Try
            For Each obj As Object In lista
                i += 1
                If CType(obj, Persona).ced = ced Then
                    Return i
                End If
            Next
            Return i
        Catch ex As Exception
            Return -1
        End Try
    End Function
    Function persona(index As Integer) As Persona
        Try
            Return CType(lista.Item(index), Persona)
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Function eliminar(c As Long) As String
        Try
            lista.RemoveAt(buscarPosicion(c))
            Return "Se elimino la Persona"
        Catch ex As Exception
            Return "Imposible eliminar intente de nuevo ..."
        End Try
    End Function
    Function total() As Integer
        Try
            Return lista.Count
        Catch ex As Exception
        End Try
        Return 0
    End Function
End Class
