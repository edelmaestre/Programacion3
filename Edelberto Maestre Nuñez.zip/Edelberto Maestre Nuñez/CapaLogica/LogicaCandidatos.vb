﻿Imports KendyAlfaro
Public Class LogicaCandidatos
    Private lista As New List(Of Candidatos)

    Function agregar(p As Candidatos) As String
        Dim msg As String = "NO Se agrego el partido con codigo" & p.ced & " al sistema"
        Try
            If validar(p.ced) Then
                lista.Add(p)
                msg = "Se agrego la persona " & p.nom & " al sistema"
            End If
            Return msg '"Se agrego la persona " & p.Nombre & " al sistema"
        Catch ex As Exception
            Return msg
        End Try

    End Function

    Private Function validar(cod As Long) As Boolean
        For index = 0 To total() - 1
            If (Candidatos(index).ced = cod) Then
                Return False
            End If
        Next
        Return True
    End Function

    Function buscar(c As Long) As Candidatos
        Try
            For Each obj As Object In lista
                If CType(obj, Candidatos).ced = c Then
                    Return CType(obj, Candidatos)
                End If
            Next
            Return Nothing
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Function buscarPosicion(ced As Long) As Integer
        Dim i As Integer = -1
        Try
            For Each obj As Object In lista
                i += 1
                If CType(obj, Candidatos).ced = ced Then
                    Return i
                End If
            Next
            Return i
        Catch ex As Exception
            Return -1
        End Try
    End Function
    Function Candidatos(index As Integer) As Candidatos
        Try
            Return CType(lista.Item(index), Candidatos)
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Function eliminar(c As Long) As String
        Try
            lista.RemoveAt(buscarPosicion(c))
            Return "Se elimino el candidato"
        Catch ex As Exception
            Return "Imposible eliminar intente de nuevo ..."
        End Try
    End Function
    Function total() As Integer
        Try
            Return lista.Count
        Catch ex As Exception

        End Try
        Return 0
    End Function
End Class
