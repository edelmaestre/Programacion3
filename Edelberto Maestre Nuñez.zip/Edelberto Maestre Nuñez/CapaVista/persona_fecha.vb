﻿Public Class persona_fecha
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        listadoGeneral()
    End Sub
End Class