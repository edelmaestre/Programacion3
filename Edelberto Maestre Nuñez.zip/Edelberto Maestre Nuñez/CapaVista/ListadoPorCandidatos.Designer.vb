﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ListadoPorCandidatos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmbCandidato = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.grilla = New System.Windows.Forms.DataGridView()
        Me.Cedula = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.nombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ciudad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.estado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.grilla, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 70
        Me.Label4.Text = "Candidato: "
        '
        'cmbCandidato
        '
        Me.cmbCandidato.FormattingEnabled = True
        Me.cmbCandidato.Location = New System.Drawing.Point(93, 85)
        Me.cmbCandidato.Name = "cmbCandidato"
        Me.cmbCandidato.Size = New System.Drawing.Size(100, 21)
        Me.cmbCandidato.TabIndex = 69
        Me.cmbCandidato.Text = "seleccione"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(95, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(387, 25)
        Me.Label3.TabIndex = 68
        Me.Label3.Text = "listado De Votantes Por Candidatos"
        '
        'grilla
        '
        Me.grilla.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grilla.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Cedula, Me.nombre, Me.ciudad, Me.fecha, Me.estado, Me.Column1})
        Me.grilla.GridColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.grilla.Location = New System.Drawing.Point(26, 122)
        Me.grilla.Name = "grilla"
        Me.grilla.Size = New System.Drawing.Size(516, 217)
        Me.grilla.TabIndex = 65
        '
        'Cedula
        '
        Me.Cedula.HeaderText = "Cedula"
        Me.Cedula.Name = "Cedula"
        '
        'nombre
        '
        Me.nombre.HeaderText = "Nombre"
        Me.nombre.Name = "nombre"
        '
        'ciudad
        '
        Me.ciudad.HeaderText = "Apellido"
        Me.ciudad.Name = "ciudad"
        '
        'fecha
        '
        Me.fecha.HeaderText = "Candidato"
        Me.fecha.Name = "fecha"
        '
        'estado
        '
        Me.estado.HeaderText = "Sexo"
        Me.estado.Name = "estado"
        '
        'Column1
        '
        Me.Column1.HeaderText = "Fecha de nacimiento"
        Me.Column1.Name = "Column1"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(212, 83)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 23)
        Me.Button1.TabIndex = 64
        Me.Button1.Text = "Consultar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ListadoPorCandidatos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(568, 373)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cmbCandidato)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.grilla)
        Me.Controls.Add(Me.Button1)
        Me.Name = "ListadoPorCandidatos"
        Me.Text = "ListadoPorCandidatos"
        CType(Me.grilla, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label4 As Label
    Friend WithEvents cmbCandidato As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents grilla As DataGridView
    Friend WithEvents Cedula As DataGridViewTextBoxColumn
    Friend WithEvents nombre As DataGridViewTextBoxColumn
    Friend WithEvents ciudad As DataGridViewTextBoxColumn
    Friend WithEvents fecha As DataGridViewTextBoxColumn
    Friend WithEvents estado As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
End Class
