﻿Public Class RangoDeFechas


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        generar()
    End Sub

    Private Sub generar()
        Dim inicial As Date
        Dim final As Date

        inicial = txtinicial.Value
        final = txtfinal.Value
        grilla.Rows.Clear()
        For j = 0 To logCan.total - 1
            If (cmbpartido.SelectedItem = logCan.Candidatos(j).parti) Then
                For k = 0 To LogPer.total - 1
                    If (logCan.Candidatos(j).nom = LogPer.persona(k).candi) And (LogPer.persona(k).fech >= inicial) And (LogPer.persona(k).fech <= final) Then
                        grilla.Rows.Add(LogPer.persona(k).fila)
                    End If
                Next
            End If
        Next


    End Sub

    Private Sub RangoDeFechas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        cmbpartido.Items.Clear()
        For j = 0 To logPar.total - 1
            cmbpartido.Items.Add(logPar.Partido(j).nompart)
        Next
    End Sub
End Class