﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formulario_principal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpcionesCuentasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpcionesSucursulesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultaDeSucursalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SucursalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClientesPorSucursalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CuentasConSaldoVaeriableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConjsultaDeMovimientosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.DarkCyan
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuToolStripMenuItem, Me.ConsultaDeSucursalesToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(902, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuToolStripMenuItem
        '
        Me.MenuToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpcionesCuentasToolStripMenuItem, Me.ToolStripMenuItem1, Me.OpcionesSucursulesToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
        Me.MenuToolStripMenuItem.Size = New System.Drawing.Size(58, 20)
        Me.MenuToolStripMenuItem.Text = "archivo"
        '
        'OpcionesCuentasToolStripMenuItem
        '
        Me.OpcionesCuentasToolStripMenuItem.Name = "OpcionesCuentasToolStripMenuItem"
        Me.OpcionesCuentasToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.OpcionesCuentasToolStripMenuItem.Text = "Partidos"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(134, 22)
        Me.ToolStripMenuItem1.Text = "Candidatos"
        '
        'OpcionesSucursulesToolStripMenuItem
        '
        Me.OpcionesSucursulesToolStripMenuItem.Name = "OpcionesSucursulesToolStripMenuItem"
        Me.OpcionesSucursulesToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.OpcionesSucursulesToolStripMenuItem.Text = "Personas"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'ConsultaDeSucursalesToolStripMenuItem
        '
        Me.ConsultaDeSucursalesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SucursalesToolStripMenuItem, Me.ClientesPorSucursalesToolStripMenuItem, Me.CuentasConSaldoVaeriableToolStripMenuItem, Me.ConjsultaDeMovimientosToolStripMenuItem})
        Me.ConsultaDeSucursalesToolStripMenuItem.Name = "ConsultaDeSucursalesToolStripMenuItem"
        Me.ConsultaDeSucursalesToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.ConsultaDeSucursalesToolStripMenuItem.Text = "Consultas"
        '
        'SucursalesToolStripMenuItem
        '
        Me.SucursalesToolStripMenuItem.Name = "SucursalesToolStripMenuItem"
        Me.SucursalesToolStripMenuItem.Size = New System.Drawing.Size(480, 22)
        Me.SucursalesToolStripMenuItem.Text = "Listado general de votantes agrupado por Partido "
        '
        'ClientesPorSucursalesToolStripMenuItem
        '
        Me.ClientesPorSucursalesToolStripMenuItem.Name = "ClientesPorSucursalesToolStripMenuItem"
        Me.ClientesPorSucursalesToolStripMenuItem.Size = New System.Drawing.Size(480, 22)
        Me.ClientesPorSucursalesToolStripMenuItem.Text = "Estadística de votación por candidato discriminado por sexo con porcentajes "
        '
        'CuentasConSaldoVaeriableToolStripMenuItem
        '
        Me.CuentasConSaldoVaeriableToolStripMenuItem.Name = "CuentasConSaldoVaeriableToolStripMenuItem"
        Me.CuentasConSaldoVaeriableToolStripMenuItem.Size = New System.Drawing.Size(480, 22)
        Me.CuentasConSaldoVaeriableToolStripMenuItem.Text = "Personas entre  un rango de fechas agrupado por Partido "
        '
        'ConjsultaDeMovimientosToolStripMenuItem
        '
        Me.ConjsultaDeMovimientosToolStripMenuItem.Name = "ConjsultaDeMovimientosToolStripMenuItem"
        Me.ConjsultaDeMovimientosToolStripMenuItem.Size = New System.Drawing.Size(480, 22)
        Me.ConjsultaDeMovimientosToolStripMenuItem.Text = "Listado de votantes por candidato. "
        '
        'formulario_principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(902, 588)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "formulario_principal"
        Me.Text = "formulario_principal"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents MenuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpcionesSucursulesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents OpcionesCuentasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConsultaDeSucursalesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SucursalesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClientesPorSucursalesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CuentasConSaldoVaeriableToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConjsultaDeMovimientosToolStripMenuItem As ToolStripMenuItem
End Class
