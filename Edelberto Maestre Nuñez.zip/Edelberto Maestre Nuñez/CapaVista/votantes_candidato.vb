﻿Public Class votantes_candidato

End Class