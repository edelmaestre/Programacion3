﻿
Public Class formulario_principal
    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ConjsultaDeMovimientosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConjsultaDeMovimientosToolStripMenuItem.Click
        ListadoPorCandidatos.ShowDialog()
    End Sub

    Private Sub OpcionesSucursulesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpcionesSucursulesToolStripMenuItem.Click
        If logCan.total >= 1 Then
            Persona.ShowDialog()
        Else
            MsgBox("No hay Candidatos Disponibles \n Para agregar un partido debe haber registrado uno o mas Candidatos")
        End If
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        If logPar.total >= 1 Then
            Candidatos.ShowDialog()
        Else
            MsgBox("No hay Partidos Disponibles \n Para agregar un partido debe haber registrado uno o mas Partidos")
        End If
    End Sub

    Private Sub OpcionesCuentasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpcionesCuentasToolStripMenuItem.Click
        Partido.ShowDialog()
    End Sub

    Private Sub formulario_principal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
    End Sub

    Private Sub ClientesPorSucursalesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClientesPorSucursalesToolStripMenuItem.Click
        estadistica.ShowDialog()
    End Sub

    Private Sub SucursalesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SucursalesToolStripMenuItem.Click
        listadoGeneral.ShowDialog()
    End Sub

    Private Sub CuentasConSaldoVaeriableToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CuentasConSaldoVaeriableToolStripMenuItem.Click
        RangoDeFechas.ShowDialog()
    End Sub
End Class