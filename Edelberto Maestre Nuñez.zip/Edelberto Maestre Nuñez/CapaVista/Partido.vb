﻿Public Class Partido
    Private Sub Partido_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        llenar_grilla()
        txtcodigo.Focus()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Guardar()
        llenar_grilla()
    End Sub
    Private Sub Guardar()
        Dim p As New KendyAlfaro.partido
        If validar() Then

            p.codpart = txtcodigo.Text
            p.nompart = txtnomPart.Text

            Dim msg As String = logPar.agregar(p)
            MsgBox(msg)
        Else
            MsgBox("no se ha podido guardar")
        End If
    End Sub

    Private Sub llenar_grilla()
        grilla.Rows.Clear()
        Try
            For index = 0 To Publico.logPar.total - 1
                grilla.Rows.Add(Publico.logPar.Partido(index).fila)
            Next
        Catch ex As Exception

        End Try

    End Sub

    Private Function validar() As Boolean
        If txtcodigo.Text = " " Then
            MsgBox("el campo cedula no puede estar vacio")
            txtcodigo.Focus()
            Return False
        End If

        If txtnomPart.Text = " " Then
            MsgBox("el campo nombre  no puede estar vacio")
            txtnomPart.Focus()
            Return False
        End If

        Return True
    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtcodigo.Text = ""
        txtnomPart.Text = ""


        txtcodigo.Focus()
    End Sub

    Private Sub eliminar_Click(sender As Object, e As EventArgs) Handles eliminar.Click

        Dim p As New KendyAlfaro.partido
        p = logPar.buscar(txtcodigo.Text)
        If p Is Nothing Then
            MsgBox("ocurrio un error qure nos impidio mostrar el partido")
        Else
            Dim esta = False
            For i = 0 To logCan.total - 1
                If (p.nompart = logCan.Candidatos(i).parti) Then
                    esta = True
                    Exit For
                End If
            Next
            If esta Then
                MsgBox("El partido no se puede eliminar")

            Else
                Dim op As MsgBoxStyle = MsgBox("estas seguro que deseas eliminar este partido?", MsgBoxStyle.OkCancel, "eliminando")
                If op = MsgBoxStyle.OkCancel Then
                    MsgBox(logPar.eliminar(p.codpart))
                    llenar_grilla()
                Else
                    MsgBox("El elemento no se borró")
                End If
            End If
        End If
    End Sub

    Private Sub Buscar_Click(sender As Object, e As EventArgs) Handles Buscar.Click
        BuscarP()
        llenar_grilla()
    End Sub

    Sub BuscarP()

        Dim p As New KendyAlfaro.partido
        Try
            p = logPar.buscar(txtcodigo.Text)
            txtcodigo.Text = p.codpart
            txtnomPart.Text = p.nompart
        Catch ex As Exception
            MsgBox("no hay campos llenos")
        End Try
    End Sub

    Private Sub grilla_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grilla.CellContentClick
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub grilla_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles grilla.CellContentDoubleClick
        ver(logPar.Partido(e.RowIndex))
    End Sub
    Sub ver(partido As KendyAlfaro.partido)
        If IsNothing(partido) Then nuevo()
        txtcodigo.Text = partido.codpart
        txtnomPart.Text = partido.nompart
    End Sub

    Private Sub nuevo()
        txtcodigo.Clear()
        txtnomPart.Clear()
        txtcodigo.Focus()
    End Sub

End Class