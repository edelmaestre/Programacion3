﻿Public Class estadistica


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        consultar()
    End Sub

    Private Sub consultar()
        Dim t As Integer = 0
        Dim h As Integer = 0
        Dim m As Integer = 0
        Dim candidato As String = cmbSelecion.SelectedItem
        For k = 0 To LogPer.total - 1
            If (LogPer.persona(k).candi = candidato) Then
                t = t + 1
                If (LogPer.persona(k).sex = "masculino") Then
                    h = h + 1
                Else
                    m = m + 1
                End If
            End If
        Next
        lbltotal.Text = t.ToString
        lblPorHombres.Text = ((h * 100) / t).ToString + " %"
        lblPorMujeres.Text = ((m * 100) / t).ToString + " %"

    End Sub

    Private Sub estadistica_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        cmbSelecion.Items.Clear()
        For k = 0 To logCan.total - 1
            cmbSelecion.Items.Add(logCan.Candidatos(k).nom)
        Next
    End Sub

    'Private Sub estadistica_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    For Each candidato As KendyAlfaro.Candidatos In logCan.listado
    '        cmbSelecion.Items.Add(candidato.nom)
    '    Next
    'End Sub
End Class