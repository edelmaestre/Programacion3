﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class estadistica
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.cmbSelecion = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lbltotal = New System.Windows.Forms.Label()
        Me.lblPorMujeres = New System.Windows.Forms.Label()
        Me.lblPorHombres = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmbSelecion
        '
        Me.cmbSelecion.FormattingEnabled = True
        Me.cmbSelecion.Location = New System.Drawing.Point(15, 43)
        Me.cmbSelecion.Name = "cmbSelecion"
        Me.cmbSelecion.Size = New System.Drawing.Size(121, 21)
        Me.cmbSelecion.TabIndex = 0
        Me.cmbSelecion.Text = "selecione"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(125, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Seleccione un canditado"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 125)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(115, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Porcentaje de mujeres:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(17, 151)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(121, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Porcentaje de Hombres:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(60, 99)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Total de votos:"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(164, 42)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(67, 21)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "consulltar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lbltotal
        '
        Me.lbltotal.AutoSize = True
        Me.lbltotal.Location = New System.Drawing.Point(161, 99)
        Me.lbltotal.Name = "lbltotal"
        Me.lbltotal.Size = New System.Drawing.Size(0, 13)
        Me.lbltotal.TabIndex = 6
        '
        'lblPorMujeres
        '
        Me.lblPorMujeres.AutoSize = True
        Me.lblPorMujeres.Location = New System.Drawing.Point(161, 125)
        Me.lblPorMujeres.Name = "lblPorMujeres"
        Me.lblPorMujeres.Size = New System.Drawing.Size(0, 13)
        Me.lblPorMujeres.TabIndex = 7
        '
        'lblPorHombres
        '
        Me.lblPorHombres.AutoSize = True
        Me.lblPorHombres.Location = New System.Drawing.Point(161, 151)
        Me.lblPorHombres.Name = "lblPorHombres"
        Me.lblPorHombres.Size = New System.Drawing.Size(0, 13)
        Me.lblPorHombres.TabIndex = 8
        '
        'estadistica
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(373, 217)
        Me.Controls.Add(Me.lblPorHombres)
        Me.Controls.Add(Me.lblPorMujeres)
        Me.Controls.Add(Me.lbltotal)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbSelecion)
        Me.Name = "estadistica"
        Me.Text = "estadistica"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmbSelecion As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents lbltotal As Label
    Friend WithEvents lblPorMujeres As Label
    Friend WithEvents lblPorHombres As Label
End Class
