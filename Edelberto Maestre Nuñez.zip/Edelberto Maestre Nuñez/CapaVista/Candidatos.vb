﻿Public Class Candidatos

    Private Sub Candidatos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbpartido.Items.Clear()
        For i = 0 To logPar.total - 1
            cmbpartido.Items.Add(logPar.Partido(i).nompart)
        Next
        Me.CenterToScreen()
        actualizarGrilla()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Guardar()
        actualizarGrilla()
    End Sub
    Private Sub Guardar()
        Dim p As New KendyAlfaro.Candidatos
        Dim msg As String
        If validar() Then

            p.ced = txtcedula.Text
            p.nom = txtnombre.Text
            p.parti = cmbpartido.SelectedItem
            If IsNothing(p.parti) Then
                msg = "no dejes campos vacios"
            Else
                msg = logCan.agregar(p)
            End If
            MsgBox(msg)
        Else
            MsgBox("no se ha podido guardar")
        End If
    End Sub
    Private Sub actualizarGrilla()
        grilla.Rows.Clear()
        For index = 0 To logCan.total - 1
            grilla.Rows.Add(logCan.Candidatos(index).fila)
        Next

    End Sub

    Private Function validar() As Boolean
        If txtcedula.Text = " " Then
            MsgBox("el campo cedula no puede estar vacio")
            txtcedula.Focus()
            Return False
        End If

        If txtnombre.Text = " " Then
            MsgBox("el campo nombre  no puede estar vacio")
            txtnombre.Focus()
            Return False
        End If
        Return True
    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtcedula.Text = ""
        txtnombre.Text = ""
        cmbpartido.Text = ""


        txtcedula.Focus()
    End Sub

    Private Sub Buscar_Click(sender As Object, e As EventArgs) Handles Buscar.Click
        BuscarP()
        actualizarGrilla()
    End Sub
    Sub BuscarP()

        Dim p As New KendyAlfaro.Candidatos
        Try
            p = logCan.buscar(txtcedula.Text)
            txtcedula.Text = p.ced
            txtnombre.Text = p.nom
            cmbpartido.SelectedItem = p.parti

        Catch ex As Exception
            MsgBox("no hay campos llenos")
        End Try




    End Sub

    Private Sub eliminar_Click(sender As Object, e As EventArgs) Handles eliminar.Click
        Dim p As New KendyAlfaro.Candidatos
        p = logCan.buscar(txtcedula.Text)
        If p Is Nothing Then
            MsgBox("ocurrio un error qure nos impidio mostrar la persona")
        Else

            Dim esta = False
            For i = 0 To logCan.total - 1
                If (p.nom = LogPer.persona(i).candi) Then
                    esta = True
                    Exit For
                End If
            Next
            If esta Then
                MsgBox("El Candidato no se puede eliminar")

            Else
                Dim op As MsgBoxStyle = MsgBox("estas seguro que deseas eliminar el Candidato?", MsgBoxStyle.OkCancel, "eliminando")
                If op = MsgBoxStyle.OkCancel Then
                    MsgBox(logCan.eliminar(p.ced))
                    actualizarGrilla()
                Else
                    MsgBox("El elemento no se borró")
                End If
            End If
        End If
    End Sub
End Class