﻿Public Class listadoGeneral
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        mostrar()
    End Sub

    Private Sub mostrar()
        grilla.Rows.Clear()
        If (cmbElec.SelectedText = "selecciona") Then
            MsgBox("error debes seleccionar un item ", MsgBoxStyle.Critical, "consultando")
        Else
            grilla.Rows.Clear()
            Dim par As String = cmbElec.SelectedItem

            For i = 0 To logCan.total - 1
                If (par = logCan.Candidatos(i).parti) Then
                    For j = 0 To LogPer.total - 1
                        If logCan.Candidatos(i).nom = LogPer.persona(j).candi Then
                            grilla.Rows.Add(LogPer.persona(j).fila)
                        End If
                    Next
                End If
            Next
        End If
    End Sub

    Private Sub listadoGeneral_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()

        cmbElec.Items.Clear()
        For i = 0 To logPar.total - 1
            cmbElec.Items.Add(logPar.Partido(i).nompart)
        Next
    End Sub

End Class