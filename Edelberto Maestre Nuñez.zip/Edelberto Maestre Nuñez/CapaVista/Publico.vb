﻿Module Publico
    Public LogPer As New CapaLogica.LogicaPersona
    Public logPar As New CapaLogica.LogicaPartido
    Public logCan As New CapaLogica.LogicaCandidatos
End Module
