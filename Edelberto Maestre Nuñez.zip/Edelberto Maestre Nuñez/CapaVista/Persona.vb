﻿Public Class Persona

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbcandidato.Items.Clear()
        For index = 0 To logCan.total - 1
            cmbcandidato.Items.Add(logCan.Candidatos(index).nom)
        Next
        Me.CenterToScreen()
        llenar_grilla()
    End Sub

    Private Sub grilla_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grilla.CellContentClick

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Guardar()
        llenar_grilla()
    End Sub

    Private Sub llenar_grilla()
        grilla.Rows.Clear()
        For index = 0 To LogPer.total - 1
            grilla.Rows.Add(LogPer.persona(index).fila)
        Next

    End Sub

    Private Sub Guardar()
        Dim p As New KendyAlfaro.Persona
        If validar() Then

            p.ced = txtcedula.Text
            p.nom = txtnombre.Text
            p.apell = txtapellido.Text
            p.candi = cmbcandidato.SelectedItem
            p.sex = cmbsexo.SelectedItem
            p.fech = fechaNa.Value

            If IsNothing(p.candi) Or IsNothing(p.ced) Or IsNothing(p.nom) Then
                MsgBox("no dejes campos vacios")
            Else
                Dim msg As String = LogPer.agregar(p)
                MsgBox(msg)

            End If
        Else
                MsgBox("no se ha podido guardar")
        End If
    End Sub

    Private Function validar() As Boolean
        If txtcedula.Text = " " Then
            MsgBox("el campo cedula no puede estar vacio")
            txtcedula.Focus()
            Return False
        End If

        If txtnombre.Text = " " Then
            MsgBox("el campo nombre  no puede estar vacio")
            txtnombre.Focus()
            Return False
        End If

        If txtapellido.Text = " " Then

            MsgBox("el campo ciudad  no puede estar vacio")
            txtapellido.Focus()
            Return False
        End If
        Return True
    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtcedula.Text = ""
        txtnombre.Text = ""
        txtapellido.Text = ""
        cmbcandidato.Text = ""
        cmbsexo.Text = ""
        fechaNa.Value = Now

        txtcedula.Focus()
    End Sub

    Private Sub eliminar_Click(sender As Object, e As EventArgs) Handles eliminar.Click
        Dim p As New KendyAlfaro.Persona
        p = LogPer.buscar(txtcedula.Text)
        If p Is Nothing Then
            MsgBox("ocurrio un error qure nos impidio mostrar la persona")
        Else


            Dim op As MsgBoxStyle = MsgBox("estas seguro que deseas eliminar la sucursal?", MsgBoxStyle.OkCancel, "eliminando")
            If op = MsgBoxStyle.OkCancel Then
                MsgBox(LogPer.eliminar(p.ced))
                llenar_grilla()
            Else
                MsgBox("El elemento no se borró")
            End If
        End If



    End Sub

    Private Sub Buscar_Click(sender As Object, e As EventArgs) Handles Buscar.Click
        BuscarP()
        llenar_grilla()
    End Sub

    Sub BuscarP()
        Try
            Dim p As New KendyAlfaro.Persona
            p = LogPer.buscar(txtcedula.Text)
            txtcedula.Text = p.ced
            txtnombre.Text = p.nom
            txtapellido.Text = p.apell
            cmbcandidato.Text = p.candi
            cmbsexo.Text = p.sex
            fechaNa.Value = p.fech
        Catch ex As Exception
            MsgBox("ha ocurrido un error ", MsgBoxStyle.Critical, "error")
        End Try


    End Sub
End Class
