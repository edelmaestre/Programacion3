﻿Public Class ListadoPorCandidatos

    Private Sub ListadoPorCandidatos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        cmbCandidato.Items.Clear()
        For index = 0 To logCan.total() - 1
            cmbCandidato.Items.Add(logCan.Candidatos(index).nom)
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        generar()
    End Sub

    Private Sub generar()
        grilla.Rows.Clear()
        For index = 0 To LogPer.total() - 1
            If (cmbCandidato.SelectedItem = LogPer.persona(index).candi) Then
                grilla.Rows.Add(LogPer.persona(index).fila)
            End If
        Next
    End Sub

End Class