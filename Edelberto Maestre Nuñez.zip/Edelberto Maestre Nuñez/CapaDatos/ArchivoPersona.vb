﻿Public Class ArchivoPersona
    Inherits Archivo
    Sub New(_ruta As String)
        MyBase.New(_ruta)
    End Sub

    Function leer() As List(Of KendyAlfaro.Persona)
        Dim aux(), linea As String
        Dim lista As New List(Of KendyAlfaro.Persona)
        Try
            Dim sr As New System.IO.StreamReader(Ruta)
            Do While Not sr.EndOfStream
                Dim p As New KendyAlfaro.Persona
                linea = sr.ReadLine
                aux = Split(linea, ";")
                p.ced = aux(0)
                p.nom = aux(1)
                p.apell = aux(2)
                p.candi = aux(3)
                p.sex = aux(4)
                p.fech = aux(5)

                lista.Add(p)
            Loop
            sr.Close()
            Return lista
        Catch ex As Exception
            Return Nothing
        End Try

    End Function


End Class
