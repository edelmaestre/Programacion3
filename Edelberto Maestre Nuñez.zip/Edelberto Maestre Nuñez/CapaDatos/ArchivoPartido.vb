﻿Imports System.IO

Public Class ArchivoPartido

    Inherits Archivo
    Sub New(_ruta As String)
        MyBase.New(_ruta)
    End Sub

    Function leer() As List(Of KendyAlfaro.partido)
        Dim aux(), linea As String
        Dim lista As New List(Of KendyAlfaro.partido)
        Try
            Dim sr As New System.IO.StreamReader(Ruta)
            Do While Not sr.EndOfStream
                Dim p As New KendyAlfaro.partido
                linea = sr.ReadLine
                aux = Split(linea, ";")
                p.codpart = aux(0)
                p.nompart = aux(1)
                lista.Add(p)
            Loop
            sr.Close()
            Return lista
        Catch ex As Exception
            Return Nothing
        End Try
    End Function


End Class
