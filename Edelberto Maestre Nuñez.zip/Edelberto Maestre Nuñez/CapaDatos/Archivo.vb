﻿Imports System.IO
Public Class Archivo
    Private r As String

    Public ReadOnly Property Ruta As String
        Get
            Return r
        End Get

    End Property

    Sub New(_ruta As String)
        r = _ruta
    End Sub
    ''' <summary>
    ''' Guarda datos en el archivo
    ''' </summary>

    Public Function guardar(datos As String) As String
        Try
            Dim sw As New StreamWriter(Ruta, True)
            sw.WriteLine(datos)
            sw.Close()
            Return "se guardaron los datos en el archivo"
        Catch ex As Exception
            Return "error al guardar los datos en el archivo"
        End Try
    End Function
    Public Sub eliminar()
        Try
            My.Computer.FileSystem.DeleteFile(Ruta)
        Catch ex As Exception
        End Try
    End Sub

End Class
