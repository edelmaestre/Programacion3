﻿Public Class Candidatos
    Private cedula As Long
    Private nombre As String
    Private partido As String

    Public Property ced() As Long
        Get
            Return cedula
        End Get
        Set(value As Long)
            cedula = value
        End Set
    End Property
    Public Property nom() As String
        Get
            Return nombre
        End Get
        Set(value As String)
            nombre = value

        End Set
    End Property

    Public Property parti() As String
        Get
            Return partido
        End Get
        Set(value As String)
            partido = value

        End Set
    End Property

    Public Function fila() As String()
        Dim v(3) As String
        v(0) = cedula
        v(1) = nombre
        v(2) = partido
        Return v
    End Function


End Class
