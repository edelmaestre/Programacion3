﻿Public Class Persona
    Private cedula As Long
    Private nombre As String
    Private apellido As String
    Private candidato As String
    Private sexo As String
    Private fecha As Date

    Public Property ced() As Long
        Get
            Return cedula
        End Get
        Set(value As Long)
            cedula = value
        End Set
    End Property
    Public Property nom() As String
        Get
            Return nombre
        End Get
        Set(value As String)
            nombre = value
        End Set
    End Property

    Public Function fila() As String()
        Dim v(6) As String
        v(0) = cedula
        v(1) = nombre
        v(2) = apellido
        v(3) = candidato
        v(4) = sexo
        v(5) = fecha

        Return v
    End Function


    Public Property apell() As String
        Get
            Return apellido
        End Get
        Set(value As String)
            apellido = value
        End Set
    End Property


    Public Property candi() As String
        Get
            Return candidato
        End Get
        Set(value As String)
            candidato = value
        End Set
    End Property

    Public Property sex() As String
        Get
            Return sexo
        End Get
        Set(value As String)
            sexo = value
        End Set
    End Property

    Public Property fech() As Date
        Get
            Return fecha
        End Get
        Set(value As Date)
            fecha = value
        End Set
    End Property

End Class
