﻿Public Class partido
    Private nombrePartido As String
    Private codigoPartido As String


    Public Property nompart() As String
        Get
            Return nombrePartido
        End Get
        Set(value As String)
            nombrePartido = value
        End Set
    End Property

    Public Property codpart() As String
        Get
            Return codigoPartido
        End Get
        Set(value As String)
            codigoPartido = value
        End Set
    End Property

    Public Function fila() As String()
        Dim v(2) As String
        v(0) = codigoPartido
        v(1) = nombrePartido
        Return v
    End Function


End Class
